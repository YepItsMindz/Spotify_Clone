import mongoose from 'mongoose';

const HistorySchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    song: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Song',
      required: true,
    },
    listenedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

export const History = mongoose.model('History', HistorySchema);
