import { History } from '../models/History.js';

export const addToHistory = async (req, res, next) => {
  const { songId } = req.body;

  try {
    await History.create({
      user: req.user.id,
      song: songId,
    });

    res.status(201).json({ message: 'Added to history' });
  } catch (err) {
    next(err);
  }
};

export const getHistory = async (req, res) => {
  try {
    const history = await History.find({ user: req.user.id })
      .populate('song')
      .sort({ listenedAt: -1 })
      .limit(50);

    res.status(200).json(history);
  } catch (err) {
    next(err);
  }
};