import express from 'express';
import requireAuth from '../middlewares/requireAuth.js';
import { addToHistory, getHistory } from '../controllers/historyController.js';

const router = express.Router();

router.use(requireAuth);

router.post('/add', addToHistory);
router.get('/', getHistory);

export default router;